Ryan Bergquist
Math 466
Final Project

Average run times of max flow algorithms

Files included:

  README.txt
  RyanBergquist_Math466_Final_Paper.pdf  - Report

  Graph1.txt - output of program
  Graph2.txt
  Graph3.txt
  Graph4.txt
  Graph5.txt
  Graph6.txt
  Graph7.txt
  Graph8.txt
  Graph9.txt
  Graph10.txt

  CapacityScalingAlg.java - program files
  PreflowPush.java
  Edge.java
  EdgeException.java
  Graph.java
  Node.java
  MaxFlow.java
  AugPath.java


Run java program. If it fails to make graph, re-run program. Each run generates a new graph to be used on the algorithms.
