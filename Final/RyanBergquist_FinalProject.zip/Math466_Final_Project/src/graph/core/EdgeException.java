
package graph.core;

public class EdgeException extends java.lang.Exception {

    public EdgeException() {
    }

    public EdgeException(String msg) {
        super(msg);
    }
}